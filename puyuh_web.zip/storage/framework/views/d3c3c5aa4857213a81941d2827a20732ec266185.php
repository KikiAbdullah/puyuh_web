<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Pendapatan | Puyuh.in</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/ionicons/css/ionicons.css">
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/typicons/src/font/typicons.css">
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../../../assets/vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="../../../assets/vendors/css/vendor.bundle.addons.css">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="../../../assets/css/shared/style.css">
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../../../assets/css/demo_1/style.css">
    <!-- End Layout styles -->
    <link rel="shortcut icon" href="../../../assets/images/favicon.ico" />
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-md-6 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body d-flex flex-column">
                                    <div class="wrapper">
                                        <h4 class="card-title mb-0">Pendapatan</h4>
                                        <p>Form Pendapatan</p>
                                        <div class="mb-4" id="net-profit-legend"></div>
                                    </div>
                                    <form class="forms-sample" method="POST" action="<?php echo e(url('api/pendapatanHarian')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="jumlah">Jumlah</label>
                                            <div class="input-group-prepend">
                                                <input type="text" class="form-control" name="jumlah" id="jumlah"
                                                    placeholder="Jumlah" required>
                                                <span class="input-group-text">Kg</span>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="harga">Harga</label>
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Rp.</span>
                                                <input type="text" class="form-control" name="harga" id="harga"
                                                    placeholder="Harga" required>
                                            </div>
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-success mr-2"
                                            onclick="alert">Submit</button>
                                        <button class="btn btn-light">Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- TABEL PRODUKSI PERBULAN -->
                    <div class="row">
                        <div class="col-md-6 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Pendapatan Harian</h4>
                                    <p class="card-description"> Per tanggal : <b><?php echo e($date); ?></b> </p>
                                    <table class="table table-hover">
                                        <thead>
                                            <tr align="center">
                                                <th>No.</th>
                                                <th>Tanggal</th>
                                                <th>Jumlah</th>
                                                <th>Harga</th>
                                                <th>Total</th>
                                                <th>Tools</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $index=1;
                                            ?>
                                            <?php $__currentLoopData = $data_pendapatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr align="center">
                                                <td><?php echo e($index++); ?></td>
                                                <td><?php echo e($data->tanggal); ?></td>
                                                <td><?php echo e($data->jumlah); ?></td>
                                                <td><?php echo e($data->harga); ?></td>
                                                <td><?php echo e($data->total); ?></td>
                                                <td></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Pendapatan Perbulan /<?php echo e($monthName); ?></h4>
                                    <p class="card-description"> Per tanggal : <b><?php echo e($date); ?></b> </p>
                                    <table class="table table-hover">
                                        <thead>
                                            <tr align="center">
                                                <th>No.</th>
                                                <th>Tanggal</th>
                                                <th>Jumlah</th>
                                                <th>Harga</th>
                                                <th>Total</th>
                                                <th>Tools</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $index=1;
                                            ?>
                                            <?php $__currentLoopData = $pendapatanPerbulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataPerbulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr align="center">
                                                <td><?php echo e($index++); ?></td>
                                                <td><?php echo e($dataPerbulan->tanggal); ?></td>
                                                <td><?php echo e($dataPerbulan->jumlah); ?></td>
                                                <td><?php echo e($dataPerbulan->harga); ?></td>
                                                <td><?php echo e($dataPerbulan->total); ?></td>
                                                <td></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Pendapatan Pertahun</h4>
                                    <p class="card-description"> Per tanggal : <b><?php echo e($date); ?></b> </p>
                                    <table class="table table-hover">
                                        <thead>
                                            <tr align="center">
                                                <th>No.</th>
                                                <th>Bulan</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $index=1;
                                            ?>
                                            <?php $__currentLoopData = $pendapatanPertahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr align="center">
                                                <td><?php echo e($pertahun->id); ?></td>
                                                <td><?php echo e($pertahun->bulan); ?> <?php echo e($pertahun->tahun); ?></td>
                                                <td><b><?php echo e($pertahun->total); ?></b></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END TABEL PRODUKSI PERBULAN -->
                </div>
                <!-- content-wrapper ends -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../../assets/vendors/js/vendor.bundle.base.js"></script>
    <script src="../../../assets/vendors/js/vendor.bundle.addons.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <script src="../../../assets/js/shared/off-canvas.js"></script>
    <script src="../../../assets/js/shared/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <!-- End custom js for this page-->
</body>

</html><?php /**PATH D:\LAPORAN AKHIR D3 (KIKI BAGUS)\neww\puyuh_web\resources\views/pendapatan/index.blade.php ENDPATH**/ ?>