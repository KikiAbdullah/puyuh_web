<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Edit Produksi | Puyuh.in</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/ionicons/css/ionicons.css">
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/typicons/src/font/typicons.css">
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../../../assets/vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="../../../assets/vendors/css/vendor.bundle.addons.css">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="../../../assets/css/shared/style.css">
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../../../assets/css/demo_1/style.css">
    <!-- End Layout styles -->
    <link rel="shortcut icon" href="../../../assets/images/favicon.ico" />
</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-md-6 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body d-flex flex-column">
                                    <div class="wrapper">
                                        <h4 class="card-title mb-0">Edit Kematian</h4>
                                        <p>Form Edit Produksi</p>
                                        <div class="mb-4" id="net-profit-legend"></div>
                                    </div>
                                    <?php $__currentLoopData = $data_laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <form class="forms-sample" method="POST"
                                        action="<?php echo e(url('/api/laporanHarian/'. $item['id'])); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="PUT">
                                        <input type="hidden" name="jenis" value="kematian">
                                        <input type="hidden" name="jumlah_telur" id="jumlah_telur"
                                            value="<?php echo e($item['jumlah_telur']); ?>">
                                        <div class="form-group">
                                            <label for="no">No. Kandang : <?php echo e($item['no_kandang']); ?></label>
                                        </div>
                                        <div class="form-group">
                                            <label for="Tanggal">Tanggal : <?php echo e($item['tanggal']); ?></label>
                                        </div>
                                        <div class="form-group">
                                            <label for="harga">Jumlah Kematian</label>
                                            <input type="number" class="form-control" name="jumlah_kematian"
                                                id="jumlah_kematian" value="<?php echo e($item['jumlah_kematian']); ?>" required>
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-success mr-2"
                                            onclick="alert">Submit</button>
                                        <button class="btn btn-light">Cancel</button>
                                    </form>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content-wrapper ends -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../../assets/vendors/js/vendor.bundle.base.js"></script>
    <script src="../../../assets/vendors/js/vendor.bundle.addons.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <script src="../../../assets/js/shared/off-canvas.js"></script>
    <script src="../../../assets/js/shared/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <!-- End custom js for this page-->
</body>

</html><?php /**PATH D:\LAPORAN AKHIR D3 (KIKI BAGUS)\neww\puyuh_web\resources\views/populasi/edit-kematian.blade.php ENDPATH**/ ?>