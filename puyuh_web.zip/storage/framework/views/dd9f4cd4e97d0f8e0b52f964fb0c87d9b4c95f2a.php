<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Populasi | Puyuh.in</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/ionicons/css/ionicons.css">
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/typicons/src/font/typicons.css">
    <link rel="stylesheet" href="../../../assets/vendors/iconfonts/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../../../assets/vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="../../../assets/vendors/css/vendor.bundle.addons.css">

    <!-- endinject -->
    <!-- plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="../../../assets/css/shared/style.css">
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../../../assets/css/demo_1/style.css">
    <!-- End Layout styles -->
    <link rel="shortcut icon" href="../../../assets/images/favicon.ico" />
</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_navbar.html -->
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-md-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <h4 class="card-title">Populasi Kandang</h4>
                                            <p class="card-description"> Per tanggal : <b><?php echo e($date); ?></b> </p>

                                        </div>
                                        <div class="col-md-2">
                                            <button type="button" class="btn btn-success mr-2" data-toggle="modal" data-target="#addKandangModal">
                                                Tambah Kandang
                                            </button>

                                            <div class="modal fade" id="addKandangModal" tabindex="-1" role="dialog" aria-labelledby="addKandangModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="addKandangModalLabel">Tambah
                                                                Kandang</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <form class="forms-sample" method="POST" action="/api/kandang">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-body">

                                                                <div class="form-group">
                                                                    <label for="noKandang">No. Kandang</label>
                                                                    <input type="text" class="form-control" name="no_kandang" id="no_kandang" placeholder="Nomor Kandang" required>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="jumlahTernak">Jumlah Ternak</label>
                                                                    <div class="input-group-prepend">
                                                                        <input type="text" class="form-control" name="jumlah_ternak" id="jumlah_ternak" placeholder="Jumlah Ternak" required>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-light" data-dismiss="modal">Close </button>
                                                                <button type="submit" name="submit" class="btn btn-success mr-2" onclick="alert">Submit</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <table class="table table-hover">
                                        <thead>
                                            <tr align="center">
                                                <th>No. Kandang</th>
                                                <th>Jumlah</th>
                                                <th>Tools</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $index=1;
                                            ?>
                                            <?php $__currentLoopData = $all_kandang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kandangs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr align="center">
                                                <td><?php echo e($kandangs->no_kandang); ?></td>
                                                <td><?php echo e($kandangs->jumlah_ternak); ?></td>
                                                <td><a class="btn btn-dark" href="/populasi/edit-kandang/<?php echo e($kandangs->id); ?>">Edit</a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Jumlah Kematian /<?php echo e($monthName); ?></h4>
                                    <p class="card-description"> Per tanggal : <b><?php echo e($date); ?></b> </p>
                                    <table class="table table-hover">
                                        <thead>
                                            <tr align="center">
                                                <th>No. Kandang</th>
                                                <th>Tanggal</th>
                                                <th>Jumlah</th>
                                                <th>Tools</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php $__currentLoopData = $populasiPerbulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $populasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr align="center">
                                                <td><?php echo e($populasi->no_kandang); ?></td>
                                                <td><?php echo e($populasi->tanggal); ?></td>
                                                <td><?php echo e($populasi->jumlah_kematian); ?></td>
                                                <td><a class="btn btn-dark" href="/populasi/edit-kematian/<?php echo e($populasi->id); ?>">Edit</a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body" style="overflow-x:auto;">
                                    <h4 class="card-title">Kematian Pertahun</h4>
                                    <p class="card-description"> Per tanggal : <b><?php echo e($date); ?></b> </p>
                                    <table class="table table-hover">
                                        <thead>
                                            <tr align="center">
                                                <th>No Kandang.</th>
                                                <th>Januari</th>
                                                <th>Februari</th>
                                                <th>Maret</th>
                                                <th>April</th>
                                                <th>Mei</th>
                                                <th>Juni</th>
                                                <th>Juli</th>
                                                <th>Agustus</th>
                                                <th>September</th>
                                                <th>Oktober</th>
                                                <th>November</th>
                                                <th>Desember</th>
                                                <th>Jumlah</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $populasiPertahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $populasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr align="center">
                                                <td><?php echo e($populasi->no_kandang); ?></td>
                                                <td><a style="color: black" href="/populasi/1"><?php echo e($populasi->januari); ?></a></td>
                                                <td><a style="color: black" href="/populasi/2"><?php echo e($populasi->februari); ?></a></td>
                                                <td><a style="color: black" href="/populasi/3"><?php echo e($populasi->maret); ?></a>
                                                </td>
                                                <td><a style="color: black" href="/populasi/4"><?php echo e($populasi->april); ?></a>
                                                </td>
                                                <td><a style="color: black" href="/populasi/5"><?php echo e($populasi->mei); ?></a>
                                                </td>
                                                <td><a style="color: black" href="/populasi/6"><?php echo e($populasi->juni); ?></a>
                                                </td>
                                                <td><a style="color: black" href="/populasi/7"><?php echo e($populasi->juli); ?></a>
                                                </td>
                                                <td><a style="color: black" href="/populasi/8"><?php echo e($populasi->agustus); ?></a></td>
                                                <td><a style="color: black" href="/populasi/9"><?php echo e($populasi->september); ?></a></td>
                                                <td><a style="color: black" href="/populasi/10"><?php echo e($populasi->oktober); ?></a></td>
                                                <td><a style="color: black" href="/populasi/11"><?php echo e($populasi->november); ?></a></td>
                                                <td><a style="color: black" href="/populasi/12"><?php echo e($populasi->desember); ?></a></td>
                                                <td><b><?php echo e($populasi->jumlah); ?></b></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content-wrapper ends -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../../assets/vendors/js/vendor.bundle.base.js"></script>
    <script src="../../../assets/vendors/js/vendor.bundle.addons.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <script src="../../../assets/js/shared/off-canvas.js"></script>
    <script src="../../../assets/js/shared/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <!-- End custom js for this page-->
    <!-- If using flash()->important() or flash()->overlay(), you'll need to pull in the JS for Twitter Bootstrap. -->
    <script src="//code.jquery.com/jquery.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

    <script>
        $('#flash-overlay-modal').modal();
    </script>
</body>

</html><?php /**PATH D:\LAPORAN AKHIR D3 (KIKI BAGUS)\neww\puyuh_web\resources\views/populasi/index.blade.php ENDPATH**/ ?>