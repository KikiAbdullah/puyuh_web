<?php

namespace App\Exceptions;

use Exception;

class TestingHttpException extends Exception
{
    //
}
