<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LaporanHarian extends Model
{
    //
}
